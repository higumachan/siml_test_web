urls = [
#    "http://higumachan725-aoj.blogspot.jp/2012/06/blog-post_29.html",
#    "http://mokuou.blogspot.jp/2012/09/6_8.html",
#    "http://minnadoo.blogspot.jp/2012/09/blog-post.html",
#    "http://hitorigoto-kokoro.blogspot.jp/2012/07/blog-post_6695.html",
    "http://d.hatena.ne.jp/laieng/20120919/1348011148",
]
